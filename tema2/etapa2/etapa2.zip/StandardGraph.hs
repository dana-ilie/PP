{-# LANGUAGE TupleSections #-}
module StandardGraph where

import qualified Data.Set as S

{-
    Graf ORIENTAT cu noduri de tipul a, reprezentat prin mulțimile (set)
    de noduri și de arce.

    Mulțimile sunt utile pentru că gestionează duplicatele și permit
    testarea egalității a două grafuri fără a ține cont de ordinea nodurilor
    și a arcelor.

    type introduce un sinonim de tip, similar cu typedef din C.
-}
type StandardGraph a = (S.Set a, S.Set (a, a))

-- data StandardGraphT = StandardGraphC {
--     nodes :: S.Set Int,
--     edges :: S.Set (Int, Int)
-- } deriving (Eq, Show)

{-
    *** TODO ***

    Construiește un graf pe baza listelor de noduri și de arce.

    Hint: S.fromList.

    Constrângerea (Ord a) afirmă că valorile tipului a trebuie să fie
    ordonabile, lucru necesar pentru reprezentarea internă a mulțimilor.
    Este doar un detaliu, cu care nu veți opera explicit în această etapă.
    Veți întâlni această constrângere și în tipurile funcțiilor de mai jos.
-}
fromComponents :: Ord a
               => [a]              -- lista nodurilor
               -> [(a, a)]         -- lista arcelor
               -> StandardGraph a  -- graful construit
fromComponents ns es = (S.fromList ns, S.fromList es)

-- fromComponents2 ns es = StandardGraphC {
--     nodes = S.fromList ns,
--     edges = S.fromList es
-- }

{-
    *** TODO ***

    Mulțimea nodurilor grafului.
-}
nodes :: StandardGraph a -> S.Set a
nodes = fst

-- nodes Empty = S.empty
-- nodes (Node a) = S.insert a S.empty
-- nodes (Overlay a b) = S.union (nodes a) (nodes b)
-- nodes (COnnect a b) = S.union (nodes a) (nodes b)

{-
    *** TODO ***

    Mulțimea arcelor grafului.
-}
edges :: StandardGraph a -> S.Set (a, a)
edges = snd

-- edges Empty = S.empty
-- edges (Node x) = S.empty
-- edges (Overlay x y) = S.union (edges x) (edges y)
-- edges (Connect x y) = (edges x) `S.union` (S.cartesianProduct (nodes x) (nodes y)) `S.union` (edges y)

{-
    Exemple de grafuri
-}
graph1 :: StandardGraph Int
graph1 = fromComponents [1, 2, 3, 3, 4] [(1, 2), (1, 3), (1, 2)]

graph2 :: StandardGraph Int
graph2 = fromComponents [4, 3, 3, 2, 1] [(1, 3), (1, 3), (1, 2)]

graph3 :: StandardGraph Int
graph3 = fromComponents [1, 2, 3, 4] [(1, 2), (1, 4), (4, 1), (2, 3), (1, 3)]

graph4 :: StandardGraph Int
graph4 = fromComponents [1, 2, 3, 4] [(1, 2), (1, 4), (4, 1), (2, 4), (1, 3)]

shouldBeTrue :: Bool
shouldBeTrue = graph1 == graph2

{-
    *** TODO ***

    Mulțimea nodurilor înspre care pleacă arce dinspre nodul curent.

    Exemplu:

    > outNeighbors 1 graph3
    fromList [2,3,4]
-}
outNeighbors :: Ord a => a -> StandardGraph a -> S.Set a
outNeighbors node graph = S.fromList $ map snd $ filter (\(x,y) -> x == node) (S.toList (edges graph))

{-
    *** TODO ***

    Mulțimea nodurilor dinspre care pleacă arce înspre nodul curent.

    Exemplu:

    > inNeighbors 1 graph3 
    fromList [4]
-}
inNeighbors :: Ord a => a -> StandardGraph a -> S.Set a
inNeighbors node graph = S.fromList $ map fst $ filter (\(x,y) -> y == node) $ S.toList (edges graph)

{-
    *** TODO ***

    Întoarce graful rezultat prin eliminarea unui nod și a arcelor în care
    acesta este implicat. Dacă nodul nu există, întoarce același graf.

    Exemplu:

    > removeNode 1 graph3
    (fromList [2,3,4],fromList [(2,3)])
-}
removeNode :: Ord a => a -> StandardGraph a -> StandardGraph a
removeNode node graph
    | S.member node (nodes graph) = (S.delete node (nodes graph), S.filter (\(x,y) -> x /= node && y /= node) (edges graph))
    | otherwise = graph

{-
    *** TODO ***

    Divizează un nod în mai multe noduri, cu eliminarea nodului inițial.
    Arcele în care era implicat vechiul nod trebuie să devină valabile
    pentru noile noduri.

    Exemplu:

    > splitNode 2 [5,6] graph3
    (fromList [1,3,4,5,6],fromList [(1,3),(1,4),(1,5),(1,6),(4,1),(5,3),(6,3)])
-}
splitNode :: Ord a
          => a                -- nodul divizat
          -> [a]              -- nodurile cu care este înlocuit
          -> StandardGraph a  -- graful existent
          -> StandardGraph a  -- graful obținut
splitNode old news graph = removeNode old (nodes graph `S.union` S.fromList news, edges graph `S.union` (S.fromList (fin old news graph) `S.union` S.fromList (fout old news graph)))

fin old news graph = foldr (\l acc -> l ++ acc) [] (map (\new -> map (\inN -> (inN, new)) (S.toList (inNeighbors old graph))) news)
fout old news graph = foldr (\l acc -> l ++ acc) [] (map (\new -> map (\outN -> (new, outN)) (S.toList (outNeighbors old graph))) news)

{-
    *** TODO ***

    Îmbină mai multe noduri într-unul singur, pe baza unei proprietăți
    respectate de nodurile îmbinate, cu eliminarea acestora. Arcele în care
    erau implicate vechile noduri vor referi nodul nou.

    Exemplu:

    > mergeNodes even 5 graph3
    (fromList [1,3,5],fromList [(1,3),(1,5),(5,1),(5,3)])
-}
mergeNodes :: Ord a
           => (a -> Bool)      -- proprietatea îndeplinită de nodurile îmbinate
           -> a                -- noul nod
           -> StandardGraph a  -- graful existent
           -> StandardGraph a  -- graful obținut
mergeNodes prop node graph = if (S.toList (S.filter prop (nodes graph))) == [] then graph
                             else remove_extra prop node (S.insert node (nodes graph), S.fromList (add_all_pairs graph prop node))

remove_extra prop node new_graph = foldl (\acc n -> if prop n then (removeNode n acc) else acc) new_graph (nodes new_graph)

add_all_pairs graph prop node = foldl (\acc nfromFilter -> acc ++ make_pairs node nfromFilter graph) [] (S.toList (S.filter prop (nodes graph))) 
                            ++ foldl (\acc (x, y) -> if (prop x) && (prop y) then acc ++ [(node, node)] else acc) [] (edges graph)
                            ++ S.toList (edges graph)

make_pairs node n graph = [(x,y) | y <- [node] , x <- S.toList(inNeighbors n graph)] ++ [(x,y) | x <- [node] , y <- S.toList(outNeighbors n graph)]

